package com.quickkeys.kb

import android.graphics.Color
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import kotlin.random.Random

class KeyboardService : InputMethodService() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var content: FrameLayout
    private var autoBtn: Button? = null
    private var resumeBtn: Button? = null
    private var speedBtn: Button? = null
    private var sizeBtn: Button? = null
    private var cat = 0
    private var abc = false
    private var shift = false
    private var running = false
    private var idx = 0
    private var sent = 0
    private var contentHeight = 120 // px base
    private var isMini = false
    private var isFloating = false

    companion object {
        private var inst: KeyboardService? = null
        fun typeText(t: String): Boolean = inst?.currentInputConnection?.commitText(t, 1) ?: false
        fun pressEnter(): Boolean { val s = inst ?: return false; s.sendNow(); return true }
    }

    override fun onCreate() { super.onCreate(); inst = this }
    override fun onDestroy() { inst = null; super.onDestroy() }

    private fun px(v: Int) = (v * resources.displayMetrics.density).toInt()
    private val prefs get() = getSharedPreferences("kb", MODE_PRIVATE)
    private fun msgs(i: Int) = (prefs.getString("t$i", "") ?: "").lines().filter { it.isNotBlank() }
    private fun catName(i: Int) = prefs.getString("n$i", "C${i + 1}") ?: "C${i + 1}"
    private fun loopOn() = prefs.getBoolean("loop", true)
    private fun autoLabel() = if (running) "⏸ $sent" else "▶ Auto"

    private fun gapBaseMs(): Long {
        val s = (prefs.getString("gap", "30") ?: "30").trim().toDoubleOrNull() ?: 30.0
        return (s * 1000).toLong().coerceIn(10000L, 300000L)
    }

    // Human-like random delay
    private fun humanDelayMs(): Long {
        val base = gapBaseMs()
        val min = when {
            base <= 30000L -> 10000L
            base <= 60000L -> 20000L
            else -> (base * 0.4).toLong()
        }
        return Random.nextLong(min, base + 1)
    }

    private fun speedLabel() = "${gapBaseMs() / 1000}s~"

    private fun saveIdx() {
        prefs.edit().putInt("last_idx_$cat", idx).apply()
    }

    private fun loadLastIdx(): Int = prefs.getInt("last_idx_$cat", 0)

    private fun btn(t: String, w: Float = 1f, ht: Int = 32, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; textSize = 11f; setTextColor(Color.WHITE)
        setBackgroundColor(0xFF4A4644.toInt()); minWidth = 0; minimumWidth = 0; setPadding(2, 0, 2, 0)
        layoutParams = LinearLayout.LayoutParams(0, px(ht), w).apply { setMargins(1, 1, 1, 1) }
        setOnClickListener { f() }
    }

    private fun smallBtn(t: String, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; textSize = 10f; setTextColor(Color.WHITE)
        setBackgroundColor(0xFF5A5553.toInt()); minWidth = 0; minimumWidth = 0; setPadding(4, 0, 4, 0)
        layoutParams = LinearLayout.LayoutParams(0, px(28), 1f).apply { setMargins(1, 1, 1, 1) }
        setOnClickListener { f() }
    }

    private fun row() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

    override fun onCreateInputView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF1F1B1A.toInt())
            setPadding(2, 2, 2, 2)
        }

        // Skip / page buttons 1-10 at top
        val skipRow = row()
        for (n in 1..10) {
            skipRow.addView(smallBtn("$n") {
                val jump = n * 10
                idx = jump
                saveIdx()
                render()
                toast("Start from msg ${jump + 1} (skip $jump)")
            })
        }
        root.addView(skipRow)

        // Category selector (compact)
        val catRow = row()
        catRow.addView(btn("<", 0.6f, 30) { if (cat > 0) { cat--; idx = 0; render() } })
        catRow.addView(btn(catName(cat), 3f, 30) { })
        catRow.addView(btn(">", 0.6f, 30) { if (cat < 99) { cat++; idx = 0; render() } })
        root.addView(catRow)

        content = FrameLayout(this)
        root.addView(content)

        // Main controls
        val bar = row()
        bar.addView(btn("ABC", 1f, 30) { abc = !abc; render() })
        bar.addView(btn("Send", 1f, 30) { sendNow() })
        val a = btn(autoLabel(), 1.4f, 30) { toggleAuto(fromStart = true) }
        autoBtn = a
        bar.addView(a)
        val r = btn("Resume", 1.2f, 30) { toggleAuto(fromStart = false) }
        resumeBtn = r
        bar.addView(r)
        bar.addView(btn("⌫", 0.8f, 30) { sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL) })
        root.addView(bar)

        // Size / speed / loop
        val bar2 = row()
        bar2.addView(btn("−", 0.7f, 28) { adjGap(-1) })
        val sp = btn(speedLabel(), 1.5f, 28) { }
        speedBtn = sp
        bar2.addView(sp)
        bar2.addView(btn("+", 0.7f, 28) { adjGap(1) })
        val sz = btn(sizeLabel(), 1.2f, 28) { toggleSize() }
        sizeBtn = sz
        bar2.addView(sz)
        bar2.addView(btn(if (isFloating) "Float ON" else "Float", 1.2f, 28) { toggleFloat() })
        root.addView(bar2)

        render()
        return root
    }

    private fun sizeLabel() = if (isMini) "Tiny" else "Small"
    private fun toggleSize() {
        isMini = !isMini
        contentHeight = if (isMini) 70 else 110
        sizeBtn?.text = sizeLabel()
        render()
    }

    private fun toggleFloat() {
        isFloating = !isFloating
        // In floating mode make even smaller and more compact
        if (isFloating) {
            contentHeight = 60
            isMini = true
        } else {
            contentHeight = 110
            isMini = false
        }
        render()
        toast(if (isFloating) "Floating mini mode" else "Normal mode")
    }

    private fun adjGap(dir: Int) {
        val cur = gapBaseMs() / 1000
        val next = (cur + dir * 5).coerceIn(10, 180)
        prefs.edit().putString("gap", next.toString()).apply()
        speedBtn?.text = speedLabel()
    }

    private fun toast(t: String) {
        // simple visual feedback via button text or ignore for now
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        setInputView(onCreateInputView())
    }

    override fun onWindowHidden() { super.onWindowHidden(); if (running) saveIdx(); stopAuto() }
    override fun onFinishInput() { super.onFinishInput(); if (running) saveIdx(); stopAuto() }

    private fun render() {
        content.removeAllViews()
        val v = if (abc) qwerty() else list()
        content.addView(v)
    }

    private fun list(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val m = msgs(cat)
        if (m.isEmpty()) {
            col.addView(TextView(this).apply {
                text = "Cat $cat empty. App khol ke messages daal."
                setTextColor(Color.LTGRAY); setPadding(px(6), px(6), px(6), px(6)); textSize = 12f
            })
        } else {
            val start = idx.coerceAtMost(m.size - 1).coerceAtLeast(0)
            m.drop(start).take(8).forEachIndexed { i, t ->
                val realIdx = start + i
                col.addView(TextView(this).apply {
                    text = "${realIdx + 1}. $t"; maxLines = 1; textSize = 12f; setTextColor(Color.WHITE)
                    setBackgroundColor(if (realIdx == idx) 0xFF6A6664.toInt() else 0xFF3A3634.toInt())
                    setPadding(px(8), px(6), px(8), px(6))
                    layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(1, 1, 1, 1) }
                    setOnClickListener {
                        currentInputConnection?.commitText(t, 1)
                        idx = realIdx + 1
                        saveIdx()
                    }
                })
            }
            if (m.size > start + 8) {
                col.addView(TextView(this).apply {
                    text = "... ${m.size - start - 8} more"
                    setTextColor(Color.GRAY); textSize = 10f; setPadding(px(4), px(2), px(4), px(2))
                })
            }
        }
        return ScrollView(this).apply {
            layoutParams = FrameLayout.LayoutParams(-1, px(contentHeight))
            addView(col)
        }
    }

    private fun qwerty(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        listOf("1234567890", "qwertyuiop", "asdfghjkl", "zxcvbnm.,?").forEach { r ->
            val rw = row()
            r.forEach { c ->
                val ch = if (shift) c.uppercaseChar() else c
                rw.addView(btn(ch.toString(), 1f, 26) { type(ch) })
            }
            col.addView(rw)
        }
        val last = row()
        last.addView(btn("⇧", 1f, 26) { shift = !shift; render() })
        last.addView(btn("space", 4f, 26) { type(' ') })
        last.addView(btn("↵", 1f, 26) { sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER) })
        col.addView(last)
        return ScrollView(this).apply {
            layoutParams = FrameLayout.LayoutParams(-1, px(contentHeight))
            addView(col)
        }
    }

    private fun type(c: Char) {
        currentInputConnection?.commitText(c.toString(), 1)
        if (shift) { shift = false; render() }
    }

    private fun sendNow() {
        if (SendAccessibility.clickSend()) return
        val ic = currentInputConnection ?: return
        if (!ic.performEditorAction(EditorInfo.IME_ACTION_SEND)) sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
    }

    private fun toggleAuto(fromStart: Boolean) {
        if (running) { stopAuto(); return }
        val m = msgs(cat)
        if (m.isEmpty()) return
        running = true
        sent = 0
        idx = if (fromStart) 0 else loadLastIdx().coerceIn(0, m.size)
        autoBtn?.text = autoLabel()
        resumeBtn?.text = "..."
        scheduleNext()
    }

    private fun scheduleNext() {
        if (!running) return
        val m = msgs(cat)
        if (m.isEmpty() || idx >= m.size) {
            if (loopOn() && m.isNotEmpty()) idx = 0 else { stopAuto(); return }
        }
        val delay = humanDelayMs()
        h.postDelayed({
            if (!running) return@postDelayed
            val mm = msgs(cat)
            if (idx >= mm.size) { stopAuto(); return@postDelayed }
            currentInputConnection?.commitText(mm[idx], 1)
            h.postDelayed({
                if (running) {
                    sendNow()
                    sent++
                    idx++
                    saveIdx()
                    autoBtn?.text = autoLabel()
                    scheduleNext()
                }
            }, 400)
        }, delay)
    }

    private fun stopAuto() {
        running = false
        h.removeCallbacksAndMessages(null)
        autoBtn?.text = autoLabel()
        resumeBtn?.text = "Resume"
        saveIdx()
    }
}
