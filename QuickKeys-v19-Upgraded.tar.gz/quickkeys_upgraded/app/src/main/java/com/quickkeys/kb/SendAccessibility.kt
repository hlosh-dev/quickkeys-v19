package com.quickkeys.kb

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

class SendAccessibility : AccessibilityService() {
    private val h = Handler(Looper.getMainLooper())
    private var runId = 0

    override fun onServiceConnected() { inst = this }
    override fun onUnbind(intent: Intent?): Boolean { inst = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun say(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

    // Ek group ka pura kaam: link kholo -> loadSec wait -> message likho -> Send -> gapSec wait -> agla group.
    // Kisi group ko join kabhi nahi karta.
    private fun startGroupRun(links: List<String>, msg: String, loadSec: Long, gapSec: Long, rounds: Int, waitMin: Long) {
        val my = ++runId
        var i = 0
        var round = 1
        say("Cycle shuru: ${links.size} groups x $rounds round. Rokne ke liye QuickKeys app kholo aur Stop dabao.")
        fun next() {
            if (my != runId) return
            if (i >= links.size) {
                if (round >= rounds) { say("Cycle poora hua ✔ ($rounds round)"); return }
                say("Round $round/$rounds poora. Agla round $waitMin minute baad. Phone unlock aur screen on rakho.")
                round++
                i = 0
                h.postDelayed({ next() }, waitMin * 60_000)
                return
            }
            val n = i + 1
            val link = links[i++]
            say("Round $round/$rounds · Group $n/${links.size} khul raha hai. $loadSec sec baad message likhunga.")
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) {
                say("Group $n ka link nahi khula. Agla group $gapSec sec baad.")
                h.postDelayed({ next() }, gapSec * 1000)
                return
            }
            h.postDelayed({
                if (my == runId) typeAndSend(msg) { ok ->
                    if (my == runId) {
                        say(if (ok) "Group $n: message bheja ✔. Agla group $gapSec sec baad."
                            else "Group $n: message nahi gaya. Agla group $gapSec sec baad.")
                        h.postDelayed({ next() }, gapSec * 1000)
                    }
                }
            }, loadSec * 1000)
        }
        next()
    }

    // Pehle message box pe focus, phir QuickKeys keyboard se text likhna (wahi tareeka jo Auto me chalta hai),
    // na chale to seedha SET_TEXT. Phir Send button.
    private fun typeAndSend(msg: String, onDone: (Boolean) -> Unit) {
        val root = rootInActiveWindow
        val input = root?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: root?.let { findEditable(it) }
        if (input == null) { onDone(false); return } // chat khula hi nahi: kuch nahi karta
        input.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        input.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        h.postDelayed({
            var typed = KeyboardService.typeText(msg)
            if (!typed) {
                val args = Bundle().apply {
                    putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, msg)
                }
                typed = input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
            }
            h.postDelayed({
                var sent = clickSend()
                if (!sent) sent = KeyboardService.pressEnter()
                onDone(typed && sent)
            }, 900)
        }, 1200)
    }

    private fun findEditable(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (n.isEditable) return n
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            findEditable(c)?.let { return it }
        }
        return null
    }

    companion object {
        private var inst: SendAccessibility? = null

        fun runGroups(links: List<String>, msg: String, loadSec: Long, gapSec: Long, rounds: Int, waitMin: Long): Boolean {
            val s = inst ?: return false
            s.startGroupRun(links, msg, loadSec, gapSec, rounds, waitMin)
            return true
        }

        fun stopRun() { inst?.let { it.runId++ } }

        /** Screen par visible "Send" button dhoondh kar click karta hai. */
        fun clickSend(): Boolean {
            val root = inst?.rootInActiveWindow ?: return false
            val hit = listOf("send", "भेजें")
                .flatMap { root.findAccessibilityNodeInfosByText(it) }
                .firstOrNull { n ->
                    val t = (n.contentDescription ?: n.text)?.toString()?.trim()?.lowercase()
                    n.isVisibleToUser && (t == "send" || t == "send message" || t == "भेजें")
                } ?: return false
            var n: AccessibilityNodeInfo? = hit
            while (n != null && !n.isClickable) n = n.parent
            return n?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: false
        }
    }
}
