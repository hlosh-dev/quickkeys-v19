package com.quickkeys.kb

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.widget.*

class MainActivity : Activity() {
    private val keys = ArrayList<Pair<String, EditText>>()
    private var currentCat = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = getSharedPreferences("kb", MODE_PRIVATE)
        val pad = (12 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }

        fun button(t: String, a: () -> Unit) {
            col.addView(Button(this).apply { text = t; isAllCaps = false; setOnClickListener { a() } })
        }
        fun label(t: String) {
            col.addView(TextView(this).apply { text = t; textSize = 15f; setPadding(0, pad, 0, 4) })
        }
        fun field(key: String, def: String, hint: String, multi: Boolean = false) {
            val e = EditText(this).apply {
                this.hint = hint
                setText(p.getString(key, def))
                if (multi) {
                    inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
                    minLines = 2
                    gravity = Gravity.TOP
                }
            }
            keys.add(key to e)
            col.addView(e)
        }

        label("QuickKeys v19 — Setup")
        button("1. Keyboard ON karo") { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        button("2. Keyboard select karo") {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }
        button("3. Auto Send ON karo (Accessibility)") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }

        label("Auto gap base (seconds) — human random iske around hoga")
        field("gap", "30", "30")

        label("Categories: 100 tak (0-99). Neeche number daal ke edit karo")
        val catInput = EditText(this).apply { hint = "Category number 0-99"; inputType = InputType.TYPE_CLASS_NUMBER; setText("0") }
        col.addView(catInput)
        val nameField = EditText(this).apply { hint = "Category name" }
        val msgField = EditText(this).apply {
            hint = "Ek line = ek message"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 4
            gravity = Gravity.TOP
        }
        col.addView(nameField)
        col.addView(msgField)
        button("Load Category") {
            val n = catInput.text.toString().toIntOrNull() ?: 0
            currentCat = n.coerceIn(0, 99)
            nameField.setText(p.getString("n$currentCat", "Cat ${currentCat + 1}"))
            msgField.setText(p.getString("t$currentCat", ""))
            toast("Category $currentCat loaded")
        }
        button("Save Category") {
            val ed = p.edit()
            ed.putString("n$currentCat", nameField.text.toString())
            ed.putString("t$currentCat", msgField.text.toString())
            ed.apply()
            toast("Category $currentCat saved")
        }

        label("Groups cycle (optional, max 20 links)")
        field("g_links", "", "https://chat.whatsapp.com/... ya https://t.me/...", true)
        field("g_msg", "", "Group message", true)
        field("g_load", "6", "Load wait sec")
        field("g_gap", "15", "Gap between groups sec")
        field("g_rounds", "3", "Rounds")
        field("g_wait", "30", "Wait between rounds min")
        button("▶ Groups cycle shuru") { runGroups() }
        button("■ Stop Groups") { SendAccessibility.stopRun(); toast("Stop") }

        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    private fun runGroups() {
        fun v(k: String) = keys.firstOrNull { it.first == k }?.second?.text?.toString() ?: ""
        val links = v("g_links").lines().map { it.trim() }.filter { it.startsWith("http") }.take(20)
        val msg = v("g_msg").trim()
        val load = (v("g_load").trim().toLongOrNull() ?: 6L).coerceAtLeast(3L)
        val gap = (v("g_gap").trim().toLongOrNull() ?: 15L).coerceAtLeast(5L)
        val rounds = (v("g_rounds").trim().toIntOrNull() ?: 1).coerceIn(1, 10)
        val waitMin = (v("g_wait").trim().toLongOrNull() ?: 30L).coerceAtLeast(10L)
        if (links.isEmpty() || msg.isEmpty()) { toast("Links aur message likho"); return }
        if (!SendAccessibility.runGroups(links, msg, load, gap, rounds, waitMin)) toast("Pehle Accessibility ON karo")
    }

    override fun onPause() {
        super.onPause()
        val ed = getSharedPreferences("kb", MODE_PRIVATE).edit()
        keys.forEach { (k, e) -> ed.putString(k, e.text.toString()) }
        ed.apply()
    }
}
